class Page(object):  # creating Page class to serve as template for other pages
    def __init__(self):  # initializing Page class
        # setting default values for Page class attributes
        self.css = pass  # private property to hold: path to css file
        # all code that will go in the <head></head> of the HTML doc
        self.__head = '''
            <!DOCTYPE html>
            <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <title>'Albert Martinez | Reusable Library | DPW-1606 WDDBS Full Sail University'</title>
                    <link href="{self.css}"; rel='stylesheet' />
                </head>
                <body>
        '''
        # html blank body attribute to be filled later by the form or result attr.
        self.__body = ''
        # the form body and form html elements
        self.__form = '''
            <header>
                <h1>Price Checkr</h1>
            </header>
            <form method="get">
                <h2>Item Info</h2>
                <p class="input-field">
                    <label for="item_name">Item Name</label>
                    <input type="text" placeholder="item name" name="item_name">
                </p>
                <hr>
                <p class="input-field"><label for="original_price">
                Original Price <span class="glyph">$</span></label>
                    <input type="number" placeholder="Original price"
                    name="original_price">
                </p>
                <hr>
                <p class="input-field">
                    <label for="discount">Discount <span class="glyph">%</span> </label>
                    <input type="number" placeholder="Discount" name="discount">
                </p>
                <hr>
                <p class="input-field">
                    <label for="qty">Quantity <span class="glyph">#</span> </label>
                    <input type="text" placeholder="qtyname" name="qty">
                </p>
                <hr>
                <input type="submit" value="submit" />
            </form>
            '''
        # defining the result body contents attribute
        self.__result = '''
            <header>
                <h2>Details</h2>
            </header>
            <div class ="details">
                <p> The {self.item_name} was originally priced at ${self.original_price}.The item's new price with the
                {discount}% discount is: </p>
                <p id ="discount_price">${discount_price}</p>
            </div>
        '''
        # closing tags to complete the html document
        self.__close = '''
            </body>
        </html>
        '''
        self.body = ''
        if self.request.GET:
            # store info from the form
            item_name = self.request.GET['item_name']
            original_price = self.request.GET['original_price']
            discount = self.request.GET['discount']
            qty = self.request.GET['qty']

            # replace the empty body attribute with the result html content since we know the form has
            # been submitted and user data has been stored
            self.page.body = '''
            <header>
            <h2>Details</h2>
        </header>
        <div class ="details">
            <p> The {self.item_name} was originally priced at ${self.original_price}.The item's new price with the
            {discount}% discount is: </p>
            <p id ="discount_price">${discount_price}</p>
        </div>
            '''
            # use the stored user entered data and populate the placeholder fields in the result page
            # using the locals() method we can pupulate these placeholder fields with stored user data
            page.body = page.body.format(**locals())
            # now that all data is filled in and ready to show, write all data to the browser for the user to see
            self.response.write(page.complete_page)
        else:
            # if no data has been entered via the form then load the page with the empty form
            page.body = page.form
            self.response.write(page.complete_page)
        self.__complete_page = (self.head + self.body + self.close)

    @property
    def css(self):
        return self.__css

    @property
    def head(self):
        return self.__head

    @property
    def close(self):
        return self.__close

    @property
    def body(self):
        return self.__body

    @property
    def complete_page(self):
        return self.__complete_page

    @property
    def form(self):
        return self.__form

    @property
    def result(self):
        return self.__result

    @css.setter
    def css(self, new_css):
        self.__css = new_css

    @head.setter
    def head(self, new_head):
        self.__head = new_head

    @close.setter
    def close(self, new_close):
        self.__close = new_close

    @body.setter
    def body(self, new_body):
        self.__body = new_body

    @complete_page.setter
    def complete_page(self, new_complete_page):
        self.__complete_page = new_complete_page

    @form.setter
    def form(self, new_form):
        self.__form = new_form

    @result.setter
    def result(self, new_result):
        self.__result = new_result


